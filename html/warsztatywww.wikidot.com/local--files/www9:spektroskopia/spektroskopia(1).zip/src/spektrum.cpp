/**************************************************************
*   powered by EasyBMP Cross-Platform Windows Bitmap Library  *
*  Author: Paul Macklin                                       *
*   email: macklin01@users.sourceforge.net                    *
*     WWW: http://easybmp.sourceforge.net                     *
*   License: GPL v 2                                          *
* Copyright: 2005-6 by the EasyBMP Project                    *
**************************************************************/
#include <iostream>
#include <fstream>
#include "EasyBMP.h"
using namespace std;
int main( int argc, char* argv[] )
{
	ofstream wyjscie;
	if( argc == 1 )
	{
		cout << "\nMozesz przekonwertowac pliki na 1 z 3 sposobow: \n\n"
		<< "          spektrum <filename1> <filename2> <filename3> ... \n"
		<< "          spektrum *.bmp \n"
		<< "          spektrum *\n\n"
		<< "Program stworzy dla kazdego pliku nowy plik z widmem"
		<< " (o tej samej nazwie, ale z koncowka .csv)\n";
		return 1;
	}
	for(int k=1 ; k < argc ; k++ )
	{
		BMFH bmfh = GetBMFH( argv[k] );
		if( bmfh.bfType == 19778 ) //sprawdzam czy typ pliku to bmp
		{
			cout << "Konwertuje " << argv[k] << " ...\n";
			char OutputName [2049]; // tworze nazwe pliku wyjsciowego 
			strcpy( OutputName , argv[k] );
			int Length = strlen(OutputName);
			OutputName[Length-4] = '.';
			OutputName[Length-3] = 'c';
			OutputName[Length-2] = 's';
			OutputName[Length-1] = 'v';
			wyjscie.open(OutputName); // tworze lub otwieram plik wyjsciowy
			BMP Image;
			Image.ReadFromFile( argv[k] );// czytam plik bmp
			double Temp=0.0;
			for( int i=0 ; i < Image.TellWidth() ; i++)
			{
				for( int j=0 ; j < Image.TellHeight() ; j++)
				{
					Temp += ( Image(i,j)->Red   ) +
					( Image(i,j)->Green ) +
					( Image(i,j)->Blue  );
				}// usredniam piksele w tym samym rzedzie
				Temp/=Image.TellHeight();
				wyjscie<<i<<"; "<<Temp<<endl;
			}
			wyjscie.close();
		}
		else
		{
			cout << "Plik " << argv[k] << " to nie bmp...\n";
		}
	}
	return 0;
}
